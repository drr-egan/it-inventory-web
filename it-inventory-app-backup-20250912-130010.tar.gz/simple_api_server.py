#!/usr/bin/env python3
"""
Simple API Server Module for Web Deployment
Simplified version of the main API server for deployment
"""
import http.server
import json
import sqlite3
import urllib.parse
import os
import threading
import time
import shutil
from datetime import datetime, timedelta
from pathlib import Path

class DatabaseBackupManager:
    """Automated database backup system with scheduled backups and cleanup"""
    
    def __init__(self, db_path, backup_dir='backups'):
        self.db_path = db_path
        self.backup_dir = Path(backup_dir)
        self.backup_interval = int(os.environ.get('BACKUP_INTERVAL_HOURS', 1)) * 3600  # 1 hour default
        self.keep_backups = int(os.environ.get('BACKUP_RETENTION_COUNT', 24))  # Keep 24 backups default
        self.backup_thread = None
        self.running = False
        
        # Create backup directory
        self.backup_dir.mkdir(exist_ok=True)
        print(f"📁 Backup directory initialized: {self.backup_dir}")
        
    def create_backup(self):
        """Create a timestamped database backup"""
        try:
            if not os.path.exists(self.db_path):
                print(f"⚠️ Database file not found: {self.db_path}")
                return None
                
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_name = f"inventory-backup-{timestamp}.db"
            backup_path = self.backup_dir / backup_name
            
            # Create backup
            shutil.copy2(self.db_path, backup_path)
            
            # Verify backup
            if backup_path.exists():
                backup_size = backup_path.stat().st_size
                original_size = Path(self.db_path).stat().st_size
                
                if backup_size == original_size:
                    print(f"✅ Database backup created: {backup_path} ({backup_size} bytes)")
                    self.cleanup_old_backups()
                    return str(backup_path)
                else:
                    print(f"❌ Backup size mismatch: original {original_size}, backup {backup_size}")
                    backup_path.unlink()  # Remove invalid backup
                    return None
            else:
                print(f"❌ Backup file was not created: {backup_path}")
                return None
                
        except Exception as e:
            print(f"🚨 Backup creation failed: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def cleanup_old_backups(self):
        """Remove old backups, keeping only the most recent ones"""
        try:
            # Get all backup files sorted by creation time (newest first)
            backup_files = sorted(
                [f for f in self.backup_dir.iterdir() 
                 if f.is_file() and f.name.startswith('inventory-backup-') and f.name.endswith('.db')],
                key=lambda x: x.stat().st_mtime,
                reverse=True
            )
            
            # Remove excess backups
            if len(backup_files) > self.keep_backups:
                for old_backup in backup_files[self.keep_backups:]:
                    try:
                        old_backup.unlink()
                        print(f"🗑️ Removed old backup: {old_backup.name}")
                    except Exception as e:
                        print(f"⚠️ Failed to remove old backup {old_backup.name}: {e}")
                        
            print(f"📊 Backup status: {len(backup_files[:self.keep_backups])} backups retained")
            
        except Exception as e:
            print(f"⚠️ Backup cleanup failed: {e}")
    
    def start_backup_scheduler(self):
        """Start the automated backup scheduler in a background thread"""
        if self.running:
            print("⚠️ Backup scheduler already running")
            return
            
        self.running = True
        
        def backup_loop():
            print(f"🔄 Starting backup scheduler (interval: {self.backup_interval}s)")
            
            # Create initial backup
            self.create_backup()
            
            while self.running:
                try:
                    time.sleep(self.backup_interval)
                    if self.running:  # Check again after sleep
                        self.create_backup()
                except Exception as e:
                    print(f"🚨 Backup scheduler error: {e}")
                    time.sleep(60)  # Wait 1 minute before retrying
        
        self.backup_thread = threading.Thread(target=backup_loop, daemon=True, name="DatabaseBackup")
        self.backup_thread.start()
        print(f"✅ Backup scheduler started (PID: {os.getpid()}, Thread: {self.backup_thread.name})")
    
    def stop_backup_scheduler(self):
        """Stop the backup scheduler"""
        self.running = False
        if self.backup_thread and self.backup_thread.is_alive():
            print("🛑 Stopping backup scheduler...")
            self.backup_thread.join(timeout=5)
            print("✅ Backup scheduler stopped")
    
    def get_backup_info(self):
        """Get information about available backups"""
        try:
            backup_files = sorted(
                [f for f in self.backup_dir.iterdir() 
                 if f.is_file() and f.name.startswith('inventory-backup-') and f.name.endswith('.db')],
                key=lambda x: x.stat().st_mtime,
                reverse=True
            )
            
            backups = []
            for backup_file in backup_files:
                stat = backup_file.stat()
                backups.append({
                    'name': backup_file.name,
                    'path': str(backup_file),
                    'size': stat.st_size,
                    'created': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    'age_hours': (datetime.now().timestamp() - stat.st_mtime) / 3600
                })
            
            return {
                'backup_count': len(backups),
                'latest_backup': backups[0] if backups else None,
                'total_size': sum(b['size'] for b in backups),
                'backups': backups[:5]  # Return only the 5 most recent
            }
            
        except Exception as e:
            print(f"⚠️ Failed to get backup info: {e}")
            return {'error': str(e)}

class RateLimiter:
    """Rate limiting system to prevent abuse"""
    
    def __init__(self, max_requests=100, time_window=60):
        self.max_requests = max_requests
        self.time_window = time_window  # seconds
        self.clients = {}
        self.blocked_ips = set()
        self.cleanup_interval = 300  # 5 minutes
        self.last_cleanup = time.time()
    
    def is_allowed(self, client_ip):
        current_time = time.time()
        
        # Clean up old entries periodically
        if current_time - self.last_cleanup > self.cleanup_interval:
            self._cleanup_old_entries(current_time)
            self.last_cleanup = current_time
        
        # Check if IP is blocked
        if client_ip in self.blocked_ips:
            return False, "IP temporarily blocked due to excessive requests"
        
        # Initialize client record if not exists
        if client_ip not in self.clients:
            self.clients[client_ip] = {
                'requests': [],
                'blocked_until': 0,
                'violation_count': 0
            }
        
        client = self.clients[client_ip]
        
        # Check if client is temporarily blocked
        if current_time < client['blocked_until']:
            return False, f"Rate limited. Try again in {int(client['blocked_until'] - current_time)} seconds"
        
        # Remove requests outside the time window
        client['requests'] = [req_time for req_time in client['requests'] 
                             if current_time - req_time < self.time_window]
        
        # Check if limit exceeded
        if len(client['requests']) >= self.max_requests:
            client['violation_count'] += 1
            
            # Progressive blocking: longer blocks for repeat offenders
            block_duration = min(300 * client['violation_count'], 3600)  # Max 1 hour
            client['blocked_until'] = current_time + block_duration
            
            # Block IP if too many violations
            if client['violation_count'] >= 5:
                self.blocked_ips.add(client_ip)
                print(f"🚫 IP {client_ip} permanently blocked after {client['violation_count']} violations")
            
            print(f"🚫 Rate limit exceeded for {client_ip}. Blocked for {block_duration} seconds")
            return False, f"Rate limit exceeded. Blocked for {block_duration} seconds"
        
        # Record this request
        client['requests'].append(current_time)
        return True, None
    
    def _cleanup_old_entries(self, current_time):
        """Clean up old client records to prevent memory leaks"""
        clients_to_remove = []
        
        for client_ip, client in self.clients.items():
            # Remove clients with no recent activity
            if (not client['requests'] or 
                current_time - max(client['requests']) > self.time_window * 2):
                if current_time > client['blocked_until']:
                    clients_to_remove.append(client_ip)
        
        for client_ip in clients_to_remove:
            del self.clients[client_ip]
        
        print(f"🧹 Cleaned up {len(clients_to_remove)} inactive rate limit entries")
    
    def get_stats(self):
        """Get rate limiting statistics"""
        current_time = time.time()
        active_clients = 0
        blocked_clients = 0
        
        for client in self.clients.values():
            if client['requests'] and current_time - max(client['requests']) < self.time_window:
                active_clients += 1
            if current_time < client['blocked_until']:
                blocked_clients += 1
        
        return {
            'total_clients': len(self.clients),
            'active_clients': active_clients,
            'blocked_clients': blocked_clients,
            'permanently_blocked_ips': len(self.blocked_ips)
        }

class InventoryAPIHandler(http.server.BaseHTTPRequestHandler):
    # Class-level managers (shared across all handler instances)
    backup_manager = None
    rate_limiter = None
    
    def __init__(self, *args, **kwargs):
        # Ensure database exists
        self.db_path = self.get_database_path()
        self.init_database()
        
        # Initialize managers on first handler creation
        if InventoryAPIHandler.backup_manager is None:
            InventoryAPIHandler.backup_manager = DatabaseBackupManager(self.db_path)
            InventoryAPIHandler.backup_manager.start_backup_scheduler()
            
        if InventoryAPIHandler.rate_limiter is None:
            InventoryAPIHandler.rate_limiter = RateLimiter(max_requests=100, time_window=60)
            print("🛡️ Rate limiter initialized (100 requests/minute)")
            
        super().__init__(*args, **kwargs)
    
    def get_database_path(self):
        """Get the appropriate database path for the environment"""
        # For Render.com deployment, use /tmp for writable storage
        if os.environ.get('RENDER'):
            db_path = "/tmp/inventory.db"
            print(f"Render environment detected, using {db_path}")
            return db_path
        
        # Check for mounted data directory (production)
        data_dir = Path("/app/data")
        if data_dir.exists():
            return str(data_dir / "inventory.db")
        
        # Local development - try existing database first
        local_db = Path("inventory.db")
        if local_db.exists():
            print(f"Found existing database: {local_db}")
            return str(local_db)
        
        # Beta directory fallback
        beta_db = Path("beta/inventory.db") 
        if beta_db.exists():
            print(f"Found beta database: {beta_db}")
            return str(beta_db)
        
        # Create new database in current directory
        print("Creating new database in current directory")
        return "inventory.db"
    
    def init_database(self):
        """Initialize database with basic tables and sample data if they don't exist"""
        try:
            # Ensure database file exists
            if not os.path.exists(self.db_path):
                print(f"Creating new database at {self.db_path}")
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create items table if not exists
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    quantity INTEGER DEFAULT 0,
                    minThreshold INTEGER DEFAULT 5,
                    category TEXT DEFAULT 'Uncategorized',
                    price REAL DEFAULT 0.0
                )
            ''')
            
            # Create users table if not exists
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    cost_code TEXT DEFAULT '',
                    firstName TEXT NOT NULL,
                    lastName TEXT NOT NULL
                )
            ''')
            
            # Create checkout history table if not exists
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS checkoutHistory (
                    id TEXT PRIMARY KEY,
                    item TEXT DEFAULT '',
                    user TEXT DEFAULT '',
                    costCode TEXT DEFAULT '',
                    dateEntered TEXT DEFAULT '',
                    jobNumber TEXT DEFAULT '',
                    notes TEXT DEFAULT '',
                    isUsed INTEGER DEFAULT 0,
                    isComplete INTEGER DEFAULT 0,
                    itemName TEXT DEFAULT '',
                    userName TEXT DEFAULT '',
                    departmentId TEXT DEFAULT '',
                    quantity INTEGER DEFAULT 1,
                    checkedOutBy TEXT DEFAULT 'System'
                )
            ''')
            
            # Add sample data if tables are empty
            cursor.execute('SELECT COUNT(*) FROM items')
            item_count = cursor.fetchone()[0]
            
            if item_count == 0:
                print("Adding sample inventory data...")
                sample_items = [
                    ('item001', 'Dell Monitor 24"', 15, 5, 'Electronics', 299.99),
                    ('item002', 'USB-C Hub', 25, 10, 'Accessories', 49.99),
                    ('item003', 'Wireless Mouse', 30, 15, 'Accessories', 29.99),
                    ('item004', 'Ethernet Cable 6ft', 50, 20, 'Cables', 12.99),
                    ('item005', 'Laptop Stand', 8, 3, 'Accessories', 79.99)
                ]
                
                cursor.executemany('''
                    INSERT INTO items (id, name, quantity, minThreshold, category, price)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', sample_items)
            
            cursor.execute('SELECT COUNT(*) FROM users')
            user_count = cursor.fetchone()[0]
            
            if user_count == 0:
                print("Adding sample user data...")
                sample_users = [
                    ('user001', 'John Doe', 'IT-001', 'John', 'Doe'),
                    ('user002', 'Jane Smith', 'IT-002', 'Jane', 'Smith'),
                    ('user003', 'Mike Wilson', 'HR-001', 'Mike', 'Wilson'),
                    ('user004', 'Sarah Johnson', 'ACC-001', 'Sarah', 'Johnson')
                ]
                
                cursor.executemany('''
                    INSERT INTO users (id, name, cost_code, firstName, lastName)
                    VALUES (?, ?, ?, ?, ?)
                ''', sample_users)
            
            conn.commit()
            conn.close()
            print(f"✅ Database initialized successfully at {self.db_path}")
            
        except Exception as e:
            print(f"❌ Database initialization error: {e}")
            import traceback
            traceback.print_exc()
    
    def send_cors_response(self, status_code, data=None):
        """Send response with CORS and security headers"""
        self.send_response(status_code)
        
        # CORS Headers
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, PATCH')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        
        # Security Headers
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('X-XSS-Protection', '1; mode=block')
        self.send_header('Referrer-Policy', 'strict-origin-when-cross-origin')
        self.send_header('Content-Security-Policy', 
            "default-src 'self'; script-src 'self'; object-src 'none'; base-uri 'self'")
        self.send_header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains')
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, private')
        self.send_header('Pragma', 'no-cache')
        
        # Rate Limiting Headers
        if hasattr(self, 'rate_limit_remaining'):
            self.send_header('X-RateLimit-Limit', '100')
            self.send_header('X-RateLimit-Remaining', str(self.rate_limit_remaining))
            self.send_header('X-RateLimit-Reset', str(int(time.time()) + 60))
        
        self.end_headers()
        
        if data is not None:
            response = json.dumps(data, default=str)
            self.wfile.write(response.encode('utf-8'))
    
    def check_rate_limit(self):
        """Check rate limiting for the current request"""
        client_ip = self.client_address[0]
        allowed, message = InventoryAPIHandler.rate_limiter.is_allowed(client_ip)
        
        if not allowed:
            print(f"🚫 Rate limit violation: {client_ip} - {message}")
            self.send_cors_response(429, {'error': 'Rate limit exceeded', 'message': message})
            return False
        
        # Set rate limit info for headers
        client_requests = len(InventoryAPIHandler.rate_limiter.clients.get(client_ip, {}).get('requests', []))
        self.rate_limit_remaining = max(0, 100 - client_requests)
        return True
    
    def do_OPTIONS(self):
        """Handle preflight requests"""
        self.send_cors_response(200)
    
    def do_GET(self):
        """Handle GET requests"""
        # Check rate limiting first
        if not self.check_rate_limit():
            return
            
        path = self.path.split('?')[0]  # Remove query parameters
        
        if path == '/items':
            self.get_items()
        elif path == '/users':
            self.get_users()
        elif path == '/checkoutHistory':
            self.get_checkout_history()
        else:
            self.send_cors_response(404, {'error': 'Endpoint not found'})
    
    def do_POST(self):
        """Handle POST requests"""
        # Check rate limiting first
        if not self.check_rate_limit():
            return
            
        path = self.path.split('?')[0]  # Remove query parameters
        
        # Read request body
        content_length = int(self.headers.get('Content-Length', 0))
        if content_length > 0:
            post_data = self.rfile.read(content_length)
            try:
                data = json.loads(post_data.decode('utf-8'))
            except json.JSONDecodeError:
                self.send_cors_response(400, {'error': 'Invalid JSON'})
                return
        else:
            data = {}
        
        if path == '/checkoutHistory':
            self.post_checkout_history(data)
        elif path == '/items':
            self.post_item(data)
        else:
            self.send_cors_response(404, {'error': 'Endpoint not found'})
    
    def do_PATCH(self):
        """Handle PATCH requests"""
        # Check rate limiting first
        if not self.check_rate_limit():
            return
            
        path_parts = self.path.split('/')
        
        # Read request body
        content_length = int(self.headers.get('Content-Length', 0))
        if content_length > 0:
            post_data = self.rfile.read(content_length)
            try:
                data = json.loads(post_data.decode('utf-8'))
            except json.JSONDecodeError:
                self.send_cors_response(400, {'error': 'Invalid JSON'})
                return
        else:
            data = {}
        
        if len(path_parts) >= 3 and path_parts[1] == 'items':
            item_id = path_parts[2]
            self.patch_item(item_id, data)
        elif len(path_parts) >= 3 and path_parts[1] == 'checkoutHistory':
            record_id = path_parts[2]
            self.patch_checkout_history(record_id, data)
        else:
            self.send_cors_response(404, {'error': 'Endpoint not found'})
    
    def do_DELETE(self):
        """Handle DELETE requests"""
        # Check rate limiting first
        if not self.check_rate_limit():
            return
            
        path_parts = self.path.split('/')
        
        if len(path_parts) >= 3 and path_parts[1] == 'checkoutHistory':
            record_id = path_parts[2]
            self.delete_checkout_history(record_id)
        else:
            self.send_cors_response(404, {'error': 'Endpoint not found'})
    
    def get_items(self):
        """Get all inventory items"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute('SELECT * FROM items')
            items = [dict(row) for row in cursor.fetchall()]
            
            conn.close()
            self.send_cors_response(200, items)
            
        except Exception as e:
            self.send_cors_response(500, {'error': str(e)})
    
    def get_users(self):
        """Get all users"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute('SELECT * FROM users')
            users = [dict(row) for row in cursor.fetchall()]
            
            conn.close()
            self.send_cors_response(200, users)
            
        except Exception as e:
            self.send_cors_response(500, {'error': str(e)})
    
    def get_checkout_history(self):
        """Get checkout history"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute('SELECT * FROM checkoutHistory ORDER BY dateEntered DESC')
            history = [dict(row) for row in cursor.fetchall()]
            
            conn.close()
            self.send_cors_response(200, history)
            
        except Exception as e:
            self.send_cors_response(500, {'error': str(e)})
    
    def post_checkout_history(self, data):
        """Add a new checkout history entry"""
        try:
            # Validate required fields
            required_fields = ['id', 'itemName', 'userName', 'departmentId', 'quantity', 'dateEntered']
            for field in required_fields:
                if field not in data:
                    self.send_cors_response(400, {'error': f'Missing required field: {field}'})
                    return
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert the new checkout entry
            cursor.execute('''
                INSERT INTO checkoutHistory 
                (id, itemName, userName, departmentId, jobNumber, quantity, dateEntered)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                data['id'],
                data['itemName'],
                data['userName'],
                data['departmentId'],
                data.get('jobNumber', ''),
                data['quantity'],
                data['dateEntered']
            ))
            
            conn.commit()
            conn.close()
            
            self.send_cors_response(201, {'message': 'Checkout entry created successfully', 'id': data['id']})
            
        except Exception as e:
            self.send_cors_response(500, {'error': str(e)})
    
    def patch_item(self, item_id, data):
        """Update an inventory item"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Check if item exists
            cursor.execute('SELECT * FROM items WHERE id = ?', (item_id,))
            item = cursor.fetchone()
            if not item:
                self.send_cors_response(404, {'error': 'Item not found'})
                return
            
            # Validate and build update query dynamically
            allowed_fields = ['name', 'quantity', 'minThreshold', 'category', 'price']
            update_fields = []
            update_values = []
            validation_errors = []
            
            for field in allowed_fields:
                if field in data:
                    value = data[field]
                    
                    # Field-specific validation
                    if field == 'name':
                        if not isinstance(value, str):
                            validation_errors.append(f'{field} must be a string')
                        elif not value.strip():
                            validation_errors.append(f'{field} cannot be empty')
                        elif len(value.strip()) > 100:
                            validation_errors.append(f'{field} must be 100 characters or less')
                        else:
                            value = value.strip()
                            
                    elif field in ['quantity', 'minThreshold']:
                        if not isinstance(value, (int, float)) or value < 0:
                            validation_errors.append(f'{field} must be a non-negative number')
                        elif value > (999999 if field == 'quantity' else 1000):
                            max_val = 999999 if field == 'quantity' else 1000
                            validation_errors.append(f'{field} cannot exceed {max_val:,}')
                        else:
                            value = int(value)
                            
                    elif field == 'price':
                        if not isinstance(value, (int, float)) or value < 0:
                            validation_errors.append(f'{field} must be a non-negative number')
                        elif value > 99999:
                            validation_errors.append(f'{field} cannot exceed $99,999')
                        else:
                            value = float(value)
                            
                    elif field == 'category':
                        if not isinstance(value, str):
                            validation_errors.append(f'{field} must be a string')
                        elif len(value.strip()) > 50:
                            validation_errors.append(f'{field} must be 50 characters or less')
                        else:
                            value = value.strip() or 'Uncategorized'
                    
                    if not validation_errors:
                        update_fields.append(f'{field} = ?')
                        update_values.append(value)
            
            if validation_errors:
                self.send_cors_response(400, {'error': 'Validation failed', 'details': validation_errors})
                return
            
            if not update_fields:
                self.send_cors_response(400, {'error': 'No valid fields to update'})
                return
            
            update_values.append(item_id)
            update_query = f'UPDATE items SET {", ".join(update_fields)} WHERE id = ?'
            
            cursor.execute(update_query, update_values)
            conn.commit()
            conn.close()
            
            self.send_cors_response(200, {'message': 'Item updated successfully', 'id': item_id})
            
        except Exception as e:
            self.send_cors_response(500, {'error': str(e)})
    
    def post_item(self, data):
        """Create a new inventory item"""
        try:
            # Comprehensive input validation
            validation_errors = []
            
            if not data:
                self.send_cors_response(400, {'error': 'Request body is required'})
                return
                
            # Validate name
            name = data.get('name', '').strip()
            if not name:
                validation_errors.append('Name is required')
            elif len(name) > 100:
                validation_errors.append('Name must be 100 characters or less')
            elif len(name) < 1:
                validation_errors.append('Name cannot be empty')
                
            # Validate quantity
            quantity = data.get('quantity', 0)
            if not isinstance(quantity, (int, float)) or quantity < 0:
                validation_errors.append('Quantity must be a non-negative number')
            elif quantity > 999999:
                validation_errors.append('Quantity cannot exceed 999,999')
                
            # Validate price
            price = data.get('price', 0.0)
            if not isinstance(price, (int, float)) or price < 0:
                validation_errors.append('Price must be a non-negative number')
            elif price > 99999:
                validation_errors.append('Price cannot exceed $99,999')
                
            # Validate minThreshold
            min_threshold = data.get('minThreshold', 5)
            if not isinstance(min_threshold, (int, float)) or min_threshold < 0:
                validation_errors.append('Minimum threshold must be a non-negative number')
            elif min_threshold > 1000:
                validation_errors.append('Minimum threshold cannot exceed 1,000')
                
            # Validate category
            category = data.get('category', 'Uncategorized').strip()
            if len(category) > 50:
                validation_errors.append('Category must be 50 characters or less')
                
            if validation_errors:
                self.send_cors_response(400, {'error': 'Validation failed', 'details': validation_errors})
                return
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Generate unique ID
            import time
            import random
            item_id = f"item{int(time.time())}{random.randint(100, 999)}"
            
            # Use validated values (already processed above)
            # Convert to appropriate types
            quantity = int(quantity)
            min_threshold = int(min_threshold)
            price = float(price)
            category = category or 'Uncategorized'
            
            cursor.execute('''
                INSERT INTO items (id, name, quantity, minThreshold, category, price)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (item_id, name, quantity, min_threshold, category, price))
            
            conn.commit()
            conn.close()
            
            self.send_cors_response(201, {
                'message': 'Item created successfully',
                'id': item_id,
                'item': {
                    'id': item_id,
                    'name': name,
                    'quantity': quantity,
                    'minThreshold': min_threshold,
                    'category': category,
                    'price': price
                }
            })
            
        except Exception as e:
            self.send_cors_response(500, {'error': str(e)})
    
    def patch_checkout_history(self, record_id, data):
        """Update a checkout history entry with transaction safety"""
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            conn.execute('BEGIN IMMEDIATE')  # Start transaction with immediate lock
            cursor = conn.cursor()
            
            # Validate input data
            if not data:
                raise ValueError('No update data provided')
            
            # Check if record exists
            cursor.execute('SELECT * FROM checkoutHistory WHERE id = ?', (record_id,))
            record = cursor.fetchone()
            if not record:
                raise ValueError('Record not found')
            
            # Build update query dynamically based on provided fields
            allowed_fields = ['itemName', 'userName', 'departmentId', 'jobNumber', 'quantity', 'dateEntered']
            update_fields = []
            update_values = []
            
            for field in allowed_fields:
                if field in data:
                    # Validate field data
                    if field == 'quantity' and (not isinstance(data[field], int) or data[field] <= 0):
                        raise ValueError(f'Invalid quantity: {data[field]}')
                    if field in ['itemName', 'userName'] and (not data[field] or len(str(data[field]).strip()) == 0):
                        raise ValueError(f'Field {field} cannot be empty')
                    
                    update_fields.append(f'{field} = ?')
                    update_values.append(data[field])
            
            if not update_fields:
                raise ValueError('No valid fields to update')
            
            update_values.append(record_id)
            update_query = f'UPDATE checkoutHistory SET {", ".join(update_fields)} WHERE id = ?'
            
            cursor.execute(update_query, update_values)
            
            # Verify update was successful
            if cursor.rowcount == 0:
                raise ValueError('No record was updated')
            
            conn.commit()
            print(f"✅ Successfully updated checkout record {record_id}")
            
            self.send_cors_response(200, {'message': 'Record updated successfully', 'id': record_id})
            
        except ValueError as e:
            if conn:
                conn.rollback()
            self.send_cors_response(400, {'error': str(e)})
            print(f"❌ Validation error updating record {record_id}: {e}")
            
        except Exception as e:
            if conn:
                conn.rollback()
            self.send_cors_response(500, {'error': 'Database error occurred'})
            print(f"🚨 Database error updating record {record_id}: {e}")
            import traceback
            traceback.print_exc()
            
        finally:
            if conn:
                conn.close()
    
    def delete_checkout_history(self, record_id):
        """Delete a checkout history entry with transaction safety"""
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            conn.execute('BEGIN IMMEDIATE')  # Start transaction with immediate lock
            cursor = conn.cursor()
            
            # Validate record_id
            if not record_id or not str(record_id).strip():
                raise ValueError('Invalid record ID')
            
            # Check if record exists
            cursor.execute('SELECT * FROM checkoutHistory WHERE id = ?', (record_id,))
            record = cursor.fetchone()
            if not record:
                raise ValueError('Record not found')
            
            # Delete the record
            cursor.execute('DELETE FROM checkoutHistory WHERE id = ?', (record_id,))
            
            # Verify deletion was successful
            if cursor.rowcount == 0:
                raise ValueError('No record was deleted')
            
            conn.commit()
            print(f"✅ Successfully deleted checkout record {record_id}")
            
            self.send_cors_response(200, {'message': 'Record deleted successfully', 'id': record_id})
            
        except ValueError as e:
            if conn:
                conn.rollback()
            if 'not found' in str(e):
                self.send_cors_response(404, {'error': str(e)})
            else:
                self.send_cors_response(400, {'error': str(e)})
            print(f"❌ Validation error deleting record {record_id}: {e}")
            
        except Exception as e:
            if conn:
                conn.rollback()
            self.send_cors_response(500, {'error': 'Database error occurred'})
            print(f"🚨 Database error deleting record {record_id}: {e}")
            import traceback
            traceback.print_exc()
            
        finally:
            if conn:
                conn.close()

if __name__ == "__main__":
    import socketserver
    
    PORT = int(os.environ.get('PORT', 3001))
    
    with socketserver.TCPServer(("", PORT), InventoryAPIHandler) as httpd:
        print(f"🗄️  Simple API Server running on port {PORT}")
        httpd.serve_forever()