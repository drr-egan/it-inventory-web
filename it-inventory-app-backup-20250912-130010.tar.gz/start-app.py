#!/usr/bin/env python3
"""
Enhanced IT Inventory Management App Launcher
Provides health monitoring, auto-recovery, and integration with Health Monitor UI
"""

import http.server
import socketserver
import webbrowser
import threading
import time
import os
import subprocess
import sys
import signal
import atexit
import json
import requests
from datetime import datetime
from urllib.parse import urlparse, parse_qs
import traceback

# --- Configuration ---
APP_PORT = 8080
DB_PORT = 3001
DB_FILE = "inventory.db"
HEALTH_CHECK_INTERVAL = 30  # seconds
MAX_RESTART_ATTEMPTS = 3
RESTART_COOLDOWN = 60  # seconds between restart attempts

class HealthAwareServerManager:
    """
    Advanced server management with health monitoring and auto-recovery
    """
    
    def __init__(self):
        self.start_time = datetime.now()
        self.db_process = None
        self.app_server = None
        self.running = True
        
        # Health metrics
        self.api_restarts = 0
        self.app_restarts = 0
        self.last_api_restart = None
        self.last_app_restart = None
        self.health_checks_failed = 0
        self.last_health_check = None
        
        # Monitoring thread
        self.monitor_thread = None
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        atexit.register(self.cleanup)
        
        print("🏥 Health-Aware Server Manager initialized")

    def _signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully"""
        print(f"\n🛑 Received signal {signum}. Shutting down gracefully...")
        self.running = False
        self.cleanup()
        sys.exit(0)

    def get_health_data(self):
        """Return health data for Health Monitor UI"""
        uptime = (datetime.now() - self.start_time).total_seconds()
        
        return {
            'launcher': {
                'status': 'running' if self.running else 'stopped',
                'uptime': int(uptime),
                'start_time': self.start_time.isoformat(),
                'api_restarts': self.api_restarts,
                'app_restarts': self.app_restarts,
                'last_api_restart': self.last_api_restart.isoformat() if self.last_api_restart else None,
                'last_app_restart': self.last_app_restart.isoformat() if self.last_app_restart else None,
                'health_checks_failed': self.health_checks_failed,
                'last_health_check': self.last_health_check.isoformat() if self.last_health_check else None,
                'auto_recovery_enabled': True,
                'monitoring_interval': HEALTH_CHECK_INTERVAL
            },
            'processes': {
                'api_server': {
                    'running': self.is_api_server_healthy(),
                    'pid': self.db_process.pid if self.db_process else None,
                    'port': DB_PORT
                },
                'app_server': {
                    'running': self.is_app_server_healthy(),
                    'port': APP_PORT
                }
            }
        }

    def is_api_server_healthy(self):
        """Check if API server is responding"""
        try:
            response = requests.get(f"http://localhost:{DB_PORT}/", timeout=5)
            return response.status_code == 200
        except:
            return False

    def is_app_server_healthy(self):
        """Check if app server is responding"""
        try:
            response = requests.get(f"http://localhost:{APP_PORT}/", timeout=5)
            return response.status_code == 200
        except:
            return False

    def start_database_server(self):
        """Start the SQLite API server with enhanced monitoring"""
        print(f"🗄️  Starting database server on port {DB_PORT}...")
        
        # Check if database exists
        if not os.path.exists(DB_FILE):
            print(f"❌ Database file '{DB_FILE}' not found!")
            print("🔧 Please run 'python3 convert-to-sqlite.py' first to create the database.")
            return False
        
        try:
            # Use Popen to run enhanced-api-server.py as a background process
            self.db_process = subprocess.Popen(
                [sys.executable, "enhanced-api-server.py"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Wait a moment and check if it started successfully
            time.sleep(2)
            if self.db_process.poll() is None and self.is_api_server_healthy():
                print(f"✅ Database server is running (PID: {self.db_process.pid})")
                return True
            else:
                print("❌ Database server failed to start properly")
                return False
                
        except Exception as e:
            print(f"❌ Failed to start database server: {e}")
            return False

    def restart_database_server(self):
        """Restart the database server with cooldown logic"""
        now = datetime.now()
        
        # Check restart cooldown
        if (self.last_api_restart and 
            (now - self.last_api_restart).total_seconds() < RESTART_COOLDOWN):
            print(f"⏱️  API server restart on cooldown for {RESTART_COOLDOWN}s")
            return False
        
        # Check max restart attempts
        if self.api_restarts >= MAX_RESTART_ATTEMPTS:
            print(f"🚫 API server has been restarted {self.api_restarts} times. Manual intervention required.")
            return False
        
        print("🔄 Restarting database server...")
        
        # Stop current process
        if self.db_process:
            try:
                self.db_process.terminate()
                self.db_process.wait(timeout=10)
            except:
                try:
                    self.db_process.kill()
                    self.db_process.wait(timeout=5)
                except:
                    pass
        
        # Start new process
        if self.start_database_server():
            self.api_restarts += 1
            self.last_api_restart = now
            print(f"✅ API server restarted successfully (restart #{self.api_restarts})")
            return True
        else:
            print("❌ Failed to restart API server")
            return False

    def start_app_server(self):
        """Start the HTTP server in a separate thread"""
        def run_server():
            print(f"🚀 Starting IT Inventory Management App on port {APP_PORT}...")
            try:
                # Ensure we are in the correct directory
                os.chdir(os.path.dirname(os.path.abspath(__file__)))
                
                # Create custom handler that can serve health data
                class HealthAwareHandler(http.server.SimpleHTTPRequestHandler):
                    def do_GET(self):
                        if self.path == '/health/launcher':
                            self.send_response(200)
                            self.send_header('Content-type', 'application/json')
                            self.send_header('Access-Control-Allow-Origin', '*')
                            self.end_headers()
                            health_data = server_manager.get_health_data()
                            self.wfile.write(json.dumps(health_data).encode())
                        elif self.path.startswith('/health/launcher/restart/'):
                            # Handle restart commands from Health Monitor
                            parts = self.path.split('/')
                            if len(parts) >= 4 and parts[4] in ['api', 'app']:
                                service = parts[4]
                                if service == 'api':
                                    success = server_manager.restart_database_server()
                                else:
                                    success = server_manager.restart_app_server()
                                
                                self.send_response(200)
                                self.send_header('Content-type', 'application/json')
                                self.send_header('Access-Control-Allow-Origin', '*')
                                self.end_headers()
                                result = {'success': success, 'service': service}
                                self.wfile.write(json.dumps(result).encode())
                            else:
                                self.send_error(400)
                        else:
                            try:
                                super().do_GET()
                            except BrokenPipeError:
                                # Client disconnected before receiving full response - this is harmless
                                pass
                            except ConnectionResetError:
                                # Client reset connection - also harmless
                                pass
                
                with socketserver.TCPServer(("", APP_PORT), HealthAwareHandler) as httpd:
                    self.app_server = httpd
                    httpd.serve_forever()
                    
            except OSError as e:
                if "Address already in use" in str(e):
                    print(f"❌ Port {APP_PORT} is already in use. Please close the other application or change the APP_PORT.")
                else:
                    print(f"❌ Error starting app server: {e}")
        
        self.app_thread = threading.Thread(target=run_server, daemon=True)
        self.app_thread.start()
        
        # Wait and verify it started
        time.sleep(2)
        if self.is_app_server_healthy():
            print(f"✅ App server is running on port {APP_PORT}")
            return True
        else:
            print("❌ App server failed to start properly")
            return False

    def restart_app_server(self):
        """Restart the app server"""
        now = datetime.now()
        
        # Check restart cooldown
        if (self.last_app_restart and 
            (now - self.last_app_restart).total_seconds() < RESTART_COOLDOWN):
            print(f"⏱️  App server restart on cooldown for {RESTART_COOLDOWN}s")
            return False
        
        # Check max restart attempts
        if self.app_restarts >= MAX_RESTART_ATTEMPTS:
            print(f"🚫 App server has been restarted {self.app_restarts} times. Manual intervention required.")
            return False
        
        print("🔄 Restarting app server...")
        
        # Stop current server
        if self.app_server:
            try:
                self.app_server.shutdown()
            except:
                pass
        
        # Start new server
        if self.start_app_server():
            self.app_restarts += 1
            self.last_app_restart = now
            print(f"✅ App server restarted successfully (restart #{self.app_restarts})")
            return True
        else:
            print("❌ Failed to restart app server")
            return False

    def health_monitor(self):
        """Continuous health monitoring with auto-recovery"""
        print(f"🏥 Starting health monitor (checking every {HEALTH_CHECK_INTERVAL}s)")
        
        while self.running:
            try:
                self.last_health_check = datetime.now()
                api_healthy = self.is_api_server_healthy()
                app_healthy = self.is_app_server_healthy()
                
                # Check API server health
                if not api_healthy:
                    print("⚠️  API server health check failed")
                    self.health_checks_failed += 1
                    if self.restart_database_server():
                        print("🔄 API server auto-recovery successful")
                    else:
                        print("❌ API server auto-recovery failed")
                
                # Check App server health
                if not app_healthy:
                    print("⚠️  App server health check failed")
                    self.health_checks_failed += 1
                    if self.restart_app_server():
                        print("🔄 App server auto-recovery successful")
                    else:
                        print("❌ App server auto-recovery failed")
                
                # Log health status periodically
                if self.last_health_check.minute % 5 == 0 and self.last_health_check.second < 30:
                    print(f"💓 Health check: API={api_healthy}, App={app_healthy}")
                
            except Exception as e:
                print(f"❌ Health monitor error: {e}")
                traceback.print_exc()
            
            time.sleep(HEALTH_CHECK_INTERVAL)

    def start_all_services(self):
        """Start all services with proper sequencing"""
        print("🚀 Starting IT Inventory Management System...")
        
        # Start database server
        if not self.start_database_server():
            print("❌ Failed to start database server. Exiting.")
            return False
        
        # Wait a moment for DB to be ready
        time.sleep(2)
        
        # Start app server
        if not self.start_app_server():
            print("❌ Failed to start app server. Exiting.")
            return False
        
        # Start health monitoring
        self.monitor_thread = threading.Thread(target=self.health_monitor, daemon=True)
        self.monitor_thread.start()
        
        # Open browser
        browser_thread = threading.Thread(target=self.open_browser, daemon=True)
        browser_thread.start()
        
        print(f"🌐 App is available at: http://localhost:{APP_PORT}")
        print(f"📊 Health data: http://localhost:{APP_PORT}/health/launcher")
        print("🏥 Health monitoring and auto-recovery enabled")
        print("📱 Press Ctrl+C to stop all servers.")
        
        return True

    def open_browser(self):
        """Opens the web browser to the app"""
        time.sleep(3)  # Wait for servers to be fully ready
        webbrowser.open(f'http://localhost:{APP_PORT}')

    def cleanup(self):
        """Clean shutdown of all services"""
        self.running = False
        
        print("\n🛑 Shutting down servers...")
        
        # Stop database server
        if self.db_process:
            try:
                print("🗄️  Stopping database server...")
                self.db_process.terminate()
                self.db_process.wait(timeout=10)
                print("✅ Database server stopped.")
            except:
                try:
                    self.db_process.kill()
                    self.db_process.wait(timeout=5)
                    print("✅ Database server force-stopped.")
                except:
                    print("⚠️  Could not stop database server process.")
        
        # Stop app server
        if self.app_server:
            try:
                print("🚀 Stopping app server...")
                self.app_server.shutdown()
                print("✅ App server stopped.")
            except:
                print("⚠️  Could not stop app server gracefully.")
        
        print("👋 Goodbye!")

    def run(self):
        """Main run loop"""
        if not self.start_all_services():
            self.cleanup()
            return
        
        try:
            # Keep main thread alive
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n👋 Ctrl+C received. Shutting down servers...")
        finally:
            self.cleanup()

# Global server manager instance
server_manager = HealthAwareServerManager()

if __name__ == "__main__":
    try:
        server_manager.run()
    except Exception as e:
        print(f"❌ Fatal error: {e}")
        traceback.print_exc()
        server_manager.cleanup()
        sys.exit(1)